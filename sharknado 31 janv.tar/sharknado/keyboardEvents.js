"use strict";

const keyboardEvents = (function() {
  return {
    onKeyDown: function(event, sceneThreeJs, screenSize, drawingData) {
      const deplacement = 1;
      const camera = sceneThreeJs.camera;
      const direction = camera.getWorldDirection();


      if(event.code == "KeyW"){
        drawingData.plane.position.add(direction);
      }
      if(event.code == "KeyB"){
        utilsData.enterMode(drawingData, sceneThreeJs, "bodyMode");
      }
      if(event.code == "Space"){
        utilsData.reinitPlane(drawingData, sceneThreeJs);
      }
      if(event.code == "KeyS"){
        drawingData.plane.position.add(direction.multiplyScalar(-1));
      }
      if(event.code == "KeyR"){
        utilsData.enterMode(drawingData, sceneThreeJs, "removeMode");
      }
      if(event.code == "KeyF"){
        utilsData.enterMode(drawingData, sceneThreeJs, "finMode");
      }
      if(event.code == "KeyT"){
        utilsData.enterMode(drawingData, sceneThreeJs, "tornadoMode");
      }
      if(event.code == "KeyA"){
        utilsData.enterMode(drawingData, sceneThreeJs, "addSharkMode");
      }
    },
  };
})();
